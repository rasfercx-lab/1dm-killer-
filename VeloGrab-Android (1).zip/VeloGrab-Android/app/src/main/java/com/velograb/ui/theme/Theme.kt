package com.velograb.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

private val VeloGrabColorScheme = darkColorScheme(
    primary = CyanAccent,
    onPrimary = AmoledBackground,
    secondary = CyanAccentPressed,
    onSecondary = TextPrimary,
    background = AmoledBackground,
    onBackground = TextPrimary,
    surface = CardSurface,
    onSurface = TextPrimary,
    surfaceVariant = ElevatedSurface,
    onSurfaceVariant = TextSecondary,
    outline = BorderHairline,
    error = ErrorRed,
    onError = TextPrimary
)

private val VeloGrabTypography = Typography(
    titleLarge = TextStyle(
        fontSize = 20.sp,
        fontWeight = FontWeight.Bold,
        color = TextPrimary
    ),
    titleMedium = TextStyle(
        fontSize = 16.sp,
        fontWeight = FontWeight.SemiBold,
        color = TextPrimary
    ),
    bodyMedium = TextStyle(
        fontSize = 14.sp,
        fontWeight = FontWeight.Normal,
        color = TextPrimary
    ),
    bodySmall = TextStyle(
        fontSize = 12.sp,
        fontWeight = FontWeight.Normal,
        color = TextSecondary
    ),
    labelMedium = TextStyle(
        fontSize = 12.sp,
        fontWeight = FontWeight.Medium,
        color = TextPrimary
    )
)

@Composable
fun VeloGrabTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = VeloGrabColorScheme,
        typography = VeloGrabTypography,
        content = content
    )
}
