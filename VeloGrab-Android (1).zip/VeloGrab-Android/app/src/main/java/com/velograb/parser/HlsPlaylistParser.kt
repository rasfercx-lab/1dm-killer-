package com.velograb.parser

import com.velograb.domain.model.DrmStatus
import com.velograb.domain.model.HlsKeyInfo
import com.velograb.domain.model.HlsMediaPlaylist
import com.velograb.domain.model.HlsSegment
import com.velograb.domain.model.StreamType
import com.velograb.domain.model.StreamVariant
import java.net.URI
import java.util.UUID

object HlsPlaylistParser {

    data class HlsParseResult(
        val isMaster: Boolean,
        val drmStatus: DrmStatus,
        val variants: List<StreamVariant>,
        val mediaPlaylist: HlsMediaPlaylist? = null
    )

    fun parse(manifestText: String, baseUrl: String): HlsParseResult {
        val drm = DrmGuard.inspectHlsManifest(manifestText)
        val lines = manifestText.lines().map { it.trim() }.filter { it.isNotEmpty() }

        val isMaster = lines.any { it.startsWith("#EXT-X-STREAM-INF") || it.startsWith("#EXT-X-MEDIA") }
        if (!isMaster) {
            val media = parseMediaPlaylist(lines, baseUrl, drm)
            val fallbackVariant = StreamVariant(
                id = UUID.randomUUID().toString(),
                labelTr = "Varsayılan Akış (Sesli)",
                resolution = "Otomatik",
                height = 720,
                bandwidthBps = 2_500_000L,
                codecs = "avc1 / mp4a",
                hasAudio = true,
                isAudioOnly = false,
                videoUrl = baseUrl,
                audioUrl = null,
                streamType = StreamType.HLS_MEDIA,
                estimatedSizeBytes = estimateSize(2_500_000L, media.segments.sumOf { it.durationSec }),
                drmStatus = drm
            )
            return HlsParseResult(
                isMaster = false,
                drmStatus = drm,
                variants = listOf(fallbackVariant),
                mediaPlaylist = media
            )
        }

        val audioRenditions = mutableMapOf<String, AudioRendition>()
        var defaultAudioUrl: String? = null

        for (line in lines) {
            if (line.startsWith("#EXT-X-MEDIA:")) {
                val attrs = parseAttributes(line.removePrefix("#EXT-X-MEDIA:"))
                if (attrs["TYPE"] == "AUDIO") {
                    val groupId = attrs["GROUP-ID"] ?: "default"
                    val uri = attrs["URI"]?.let { resolveUrl(baseUrl, it) }
                    val isDefault = attrs["DEFAULT"] == "YES" || attrs["AUTOSELECT"] == "YES"
                    val name = attrs["NAME"] ?: attrs["LANGUAGE"] ?: "Türkçe / Orijinal"
                    if (!uri.isNullOrBlank()) {
                        val rendition = AudioRendition(groupId, name, uri, isDefault)
                        if (!audioRenditions.containsKey(groupId) || isDefault) {
                            audioRenditions[groupId] = rendition
                        }
                        if (defaultAudioUrl == null || isDefault) {
                            defaultAudioUrl = uri
                        }
                    }
                }
            }
        }

        val variants = mutableListOf<StreamVariant>()
        var i = 0
        while (i < lines.size) {
            val line = lines[i]
            if (line.startsWith("#EXT-X-STREAM-INF:")) {
                val attrs = parseAttributes(line.removePrefix("#EXT-X-STREAM-INF:"))
                val nextUrlLine = lines.drop(i + 1).firstOrNull { !it.startsWith("#") }
                if (nextUrlLine != null) {
                    val videoUrl = resolveUrl(baseUrl, nextUrlLine)
                    val bandwidth = attrs["BANDWIDTH"]?.toLongOrNull() ?: 0L
                    val resolution = attrs["RESOLUTION"] ?: ""
                    val height = resolution.substringAfter('x', "").toIntOrNull()
                        ?: inferHeightFromBandwidth(bandwidth)
                    val codecs = attrs["CODECS"] ?: "H.264 / AAC"
                    val audioGroup = attrs["AUDIO"]
                    val matchedAudio = audioGroup?.let { audioRenditions[it]?.uri } ?: defaultAudioUrl
                    val hasMuxedAudioInCodecs = codecs.contains("mp4a", ignoreCase = true) ||
                        codecs.contains("opus", ignoreCase = true) ||
                        codecs.contains("ec-3", ignoreCase = true) ||
                        audioRenditions.isEmpty()

                    val hasAudio = matchedAudio != null || hasMuxedAudioInCodecs
                    val qualityTitle = formatQualityLabelTr(height, hasAudio)

                    variants += StreamVariant(
                        id = "${height}_${bandwidth}_${variants.size}",
                        labelTr = qualityTitle,
                        resolution = if (resolution.isNotBlank()) resolution else "${height}p",
                        height = height,
                        bandwidthBps = bandwidth,
                        codecs = codecs,
                        hasAudio = hasAudio,
                        isAudioOnly = false,
                        videoUrl = videoUrl,
                        audioUrl = matchedAudio,
                        streamType = StreamType.HLS_MEDIA,
                        estimatedSizeBytes = null,
                        drmStatus = drm
                    )
                }
            }
            i++
        }

        // Also offer an audio-only M4A/AAC option when an audio rendition exists
        val bestAudio = audioRenditions.values.firstOrNull()
        if (bestAudio != null) {
            variants += StreamVariant(
                id = "audio_only_${bestAudio.groupId}",
                labelTr = "Sadece Ses (M4A/AAC)",
                resolution = "Ses",
                height = 0,
                bandwidthBps = 192_000L,
                codecs = "mp4a.40.2",
                hasAudio = true,
                isAudioOnly = true,
                videoUrl = bestAudio.uri,
                audioUrl = null,
                streamType = StreamType.AUDIO_ONLY,
                estimatedSizeBytes = null,
                drmStatus = drm
            )
        }

        val sorted = variants.sortedWith(
            compareByDescending<StreamVariant> { !it.isAudioOnly }
                .thenByDescending { it.height }
                .thenByDescending { it.bandwidthBps }
        )

        return HlsParseResult(
            isMaster = true,
            drmStatus = drm,
            variants = sorted
        )
    }

    fun parseMediaPlaylist(manifestText: String, baseUrl: String): HlsMediaPlaylist {
        val drm = DrmGuard.inspectHlsManifest(manifestText)
        val lines = manifestText.lines().map { it.trim() }.filter { it.isNotEmpty() }
        return parseMediaPlaylist(lines, baseUrl, drm)
    }

    private fun parseMediaPlaylist(
        lines: List<String>,
        baseUrl: String,
        drmStatus: DrmStatus
    ): HlsMediaPlaylist {
        var targetDuration = 6.0
        var mediaSequence = 0
        var currentDuration = 6.0
        var currentInitUrl: String? = null
        var currentKey: HlsKeyInfo? = null
        var currentByteRange: String? = null
        val segments = mutableListOf<HlsSegment>()

        for (line in lines) {
            when {
                line.startsWith("#EXT-X-TARGETDURATION:") -> {
                    targetDuration = line.substringAfter(':').toDoubleOrNull() ?: 6.0
                }
                line.startsWith("#EXT-X-MEDIA-SEQUENCE:") -> {
                    mediaSequence = line.substringAfter(':').toIntOrNull() ?: 0
                }
                line.startsWith("#EXT-X-MAP:") -> {
                    val attrs = parseAttributes(line.removePrefix("#EXT-X-MAP:"))
                    currentInitUrl = attrs["URI"]?.let { resolveUrl(baseUrl, it) }
                }
                line.startsWith("#EXT-X-KEY:") -> {
                    val attrs = parseAttributes(line.removePrefix("#EXT-X-KEY:"))
                    val method = attrs["METHOD"] ?: "NONE"
                    currentKey = if (method.equals("NONE", ignoreCase = true)) {
                        null
                    } else {
                        HlsKeyInfo(
                            method = method,
                            uri = attrs["URI"]?.let { resolveUrl(baseUrl, it) },
                            ivHex = attrs["IV"]
                        )
                    }
                }
                line.startsWith("#EXTINF:") -> {
                    currentDuration = line.removePrefix("#EXTINF:")
                        .substringBefore(',')
                        .toDoubleOrNull() ?: targetDuration
                }
                line.startsWith("#EXT-X-BYTERANGE:") -> {
                    currentByteRange = line.removePrefix("#EXT-X-BYTERANGE:")
                }
                !line.startsWith("#") -> {
                    val segIndex = mediaSequence + segments.size
                    segments += HlsSegment(
                        index = segIndex,
                        url = resolveUrl(baseUrl, line),
                        durationSec = currentDuration,
                        initSegmentUrl = currentInitUrl,
                        byteRange = currentByteRange,
                        keyInfo = currentKey
                    )
                    currentByteRange = null
                }
            }
        }

        return HlsMediaPlaylist(
            targetDurationSec = targetDuration,
            segments = segments,
            drmStatus = drmStatus
        )
    }

    fun formatQualityLabelTr(height: Int, hasAudio: Boolean): String {
        val resName = when {
            height >= 2160 -> "2160p 4K UHD"
            height >= 1440 -> "1440p QHD"
            height >= 1080 -> "1080p Full HD"
            height >= 720 -> "720p HD"
            height >= 480 -> "480p SD"
            height >= 360 -> "360p"
            else -> "${height}p"
        }
        val audioTag = if (hasAudio) "(Sesli)" else "(Sessiz Görüntü)"
        return "$resName $audioTag"
    }

    fun resolveUrl(baseUrl: String, relativeOrAbsolute: String): String {
        return try {
            URI(baseUrl).resolve(relativeOrAbsolute).toString()
        } catch (_: Exception) {
            relativeOrAbsolute
        }
    }

    fun parseAttributes(raw: String): Map<String, String> {
        val result = mutableMapOf<String, String>()
        val regex = Regex("""([A-Z0-9-]+)=("([^"]*)"|[^,]*)""")
        regex.findAll(raw).forEach { match ->
            val key = match.groupValues[1]
            val quoted = match.groupValues[3]
            val unquoted = match.groupValues[2]
            result[key] = if (unquoted.startsWith("\"")) quoted else unquoted
        }
        return result
    }

    private fun inferHeightFromBandwidth(bandwidthBps: Long): Int = when {
        bandwidthBps >= 8_000_000 -> 2160
        bandwidthBps >= 4_000_000 -> 1080
        bandwidthBps >= 2_000_000 -> 720
        bandwidthBps >= 900_000 -> 480
        else -> 360
    }

    private fun estimateSize(bandwidthBps: Long, durationSec: Double): Long? {
        if (bandwidthBps <= 0 || durationSec <= 0) return null
        return ((bandwidthBps / 8.0) * durationSec).toLong()
    }

    private data class AudioRendition(
        val groupId: String,
        val name: String,
        val uri: String,
        val isDefault: Boolean
    )
}
