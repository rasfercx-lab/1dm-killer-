package com.velograb.domain.model

import org.json.JSONObject

enum class StreamType {
    HLS_MASTER,
    HLS_MEDIA,
    DASH_MPD,
    DIRECT_MP4,
    DIRECT_WEBM,
    AUDIO_ONLY
}

data class StreamHeaders(
    val userAgent: String,
    val referer: String,
    val origin: String,
    val cookie: String
) {
    fun toJson(): String {
        return JSONObject().apply {
            put("userAgent", userAgent)
            put("referer", referer)
            put("origin", origin)
            put("cookie", cookie)
        }.toString()
    }

    companion object {
        fun fromJson(json: String?): StreamHeaders {
            if (json.isNullOrBlank()) {
                return StreamHeaders(
                    userAgent = DEFAULT_MOBILE_UA,
                    referer = "",
                    origin = "",
                    cookie = ""
                )
            }
            return try {
                val obj = JSONObject(json)
                StreamHeaders(
                    userAgent = obj.optString("userAgent", DEFAULT_MOBILE_UA),
                    referer = obj.optString("referer", ""),
                    origin = obj.optString("origin", ""),
                    cookie = obj.optString("cookie", "")
                )
            } catch (_: Exception) {
                StreamHeaders(DEFAULT_MOBILE_UA, "", "", "")
            }
        }

        const val DEFAULT_MOBILE_UA =
            "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36"
        const val DEFAULT_DESKTOP_UA =
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
    }
}

sealed class DrmStatus {
    data object Clear : DrmStatus()
    data class Protected(val scheme: String, val message: String) : DrmStatus()
}

data class DetectedStream(
    val id: String,
    val url: String,
    val pageTitle: String,
    val pageUrl: String,
    val mimeType: String,
    val streamType: StreamType,
    val headers: StreamHeaders,
    val detectedAtMillis: Long = System.currentTimeMillis(),
    val contentLengthBytes: Long? = null,
    val isParsed: Boolean = false,
    val drmStatus: DrmStatus = DrmStatus.Clear,
    val variants: List<StreamVariant> = emptyList(),
    val parseError: String? = null
)

data class StreamVariant(
    val id: String,
    val labelTr: String,
    val resolution: String,
    val height: Int,
    val bandwidthBps: Long,
    val codecs: String,
    val hasAudio: Boolean,
    val isAudioOnly: Boolean,
    val videoUrl: String,
    val audioUrl: String? = null,
    val streamType: StreamType,
    val estimatedSizeBytes: Long? = null,
    val drmStatus: DrmStatus = DrmStatus.Clear
)

data class HlsKeyInfo(
    val method: String,
    val uri: String?,
    val ivHex: String?
)

data class HlsSegment(
    val index: Int,
    val url: String,
    val durationSec: Double,
    val initSegmentUrl: String? = null,
    val byteRange: String? = null,
    val keyInfo: HlsKeyInfo? = null
)

data class HlsMediaPlaylist(
    val targetDurationSec: Double,
    val segments: List<HlsSegment>,
    val drmStatus: DrmStatus = DrmStatus.Clear
)

data class DashMediaTrack(
    val id: String,
    val mimeType: String,
    val codecs: String,
    val width: Int,
    val height: Int,
    val bandwidthBps: Long,
    val initUrl: String?,
    val segmentUrls: List<String>,
    val durationSec: Double,
    val isAudio: Boolean,
    val drmStatus: DrmStatus = DrmStatus.Clear
)

data class ParsedDashManifest(
    val durationSec: Double,
    val videoTracks: List<DashMediaTrack>,
    val audioTracks: List<DashMediaTrack>,
    val drmStatus: DrmStatus = DrmStatus.Clear
)
