package com.velograb.parser

import android.util.Xml
import com.velograb.domain.model.DashMediaTrack
import com.velograb.domain.model.DrmStatus
import com.velograb.domain.model.ParsedDashManifest
import com.velograb.domain.model.StreamType
import com.velograb.domain.model.StreamVariant
import org.xmlpull.v1.XmlPullParser
import java.io.StringReader
import kotlin.math.ceil

object DashMpdParser {

    fun parseToVariants(mpdXml: String, baseUrl: String): Pair<DrmStatus, List<StreamVariant>> {
        val parsed = parseManifest(mpdXml, baseUrl)
        val bestAudio = parsed.audioTracks.maxByOrNull { it.bandwidthBps }

        val variants = mutableListOf<StreamVariant>()
        for (video in parsed.videoTracks.sortedByDescending { it.height }.thenByDescending { it.bandwidthBps }) {
            val totalBps = video.bandwidthBps + (bestAudio?.bandwidthBps ?: 0L)
            val estimatedBytes = if (parsed.durationSec > 0 && totalBps > 0) {
                ((totalBps / 8.0) * parsed.durationSec).toLong()
            } else null

            val effectiveDrm = if (video.drmStatus is DrmStatus.Protected) video.drmStatus else parsed.drmStatus
            val label = HlsPlaylistParser.formatQualityLabelTr(video.height, bestAudio != null)

            variants += StreamVariant(
                id = "dash_${video.id}",
                labelTr = label,
                resolution = if (video.width > 0 && video.height > 0) "${video.width}x${video.height}" else "${video.height}p",
                height = video.height,
                bandwidthBps = totalBps,
                codecs = video.codecs.ifBlank { "avc1 + mp4a" },
                hasAudio = bestAudio != null,
                isAudioOnly = false,
                videoUrl = baseUrl,
                audioUrl = bestAudio?.id,
                streamType = StreamType.DASH_MPD,
                estimatedSizeBytes = estimatedBytes,
                drmStatus = effectiveDrm
            )
        }

        if (bestAudio != null) {
            val audioEstBytes = if (parsed.durationSec > 0 && bestAudio.bandwidthBps > 0) {
                ((bestAudio.bandwidthBps / 8.0) * parsed.durationSec).toLong()
            } else null
            variants += StreamVariant(
                id = "dash_audio_${bestAudio.id}",
                labelTr = "Sadece Ses (M4A/AAC)",
                resolution = "Ses",
                height = 0,
                bandwidthBps = bestAudio.bandwidthBps,
                codecs = bestAudio.codecs.ifBlank { "mp4a.40.2" },
                hasAudio = true,
                isAudioOnly = true,
                videoUrl = baseUrl,
                audioUrl = bestAudio.id,
                streamType = StreamType.AUDIO_ONLY,
                estimatedSizeBytes = audioEstBytes,
                drmStatus = parsed.drmStatus
            )
        }

        return parsed.drmStatus to variants
    }

    fun parseManifest(mpdXml: String, baseUrl: String): ParsedDashManifest {
        val parser = Xml.newPullParser()
        parser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false)
        parser.setInput(StringReader(mpdXml))

        var durationSec = 0.0
        var globalDrm: DrmStatus = DrmStatus.Clear
        var mpdBaseUrl = baseUrl

        var inAdaptationSet = false
        var adaptationContentType = ""
        var adaptationMimeType = ""
        var adaptationDrm: DrmStatus = DrmStatus.Clear
        var adaptationTemplate: SegmentTemplateInfo? = null

        var inRepresentation = false
        var repId = ""
        var repWidth = 0
        var repHeight = 0
        var repBandwidth = 0L
        var repCodecs = ""
        var repMime = ""
        var repBaseUrl: String? = null
        var repTemplate: SegmentTemplateInfo? = null
        val timelineNumbers = mutableListOf<Long>()

        val videoTracks = mutableListOf<DashMediaTrack>()
        val audioTracks = mutableListOf<DashMediaTrack>()

        var eventType = parser.eventType
        while (eventType != XmlPullParser.END_DOCUMENT) {
            when (eventType) {
                XmlPullParser.START_TAG -> {
                    when (parser.name) {
                        "MPD" -> {
                            durationSec = parseIsoDurationSeconds(
                                parser.getAttributeValue(null, "mediaPresentationDuration")
                            )
                        }
                        "BaseURL" -> {
                            val text = parser.nextText().trim()
                            if (text.isNotEmpty()) {
                                val resolved = HlsPlaylistParser.resolveUrl(baseUrl, text)
                                if (inRepresentation) repBaseUrl = resolved else if (!inAdaptationSet) mpdBaseUrl = resolved
                            }
                        }
                        "ContentProtection" -> {
                            val scheme = parser.getAttributeValue(null, "schemeIdUri")
                            val value = parser.getAttributeValue(null, "value")
                            val checked = DrmGuard.inspectDashContentProtection(scheme, value)
                            if (checked is DrmStatus.Protected) {
                                if (inAdaptationSet) adaptationDrm = checked else globalDrm = checked
                            }
                        }
                        "AdaptationSet" -> {
                            inAdaptationSet = true
                            adaptationContentType = parser.getAttributeValue(null, "contentType").orEmpty()
                            adaptationMimeType = parser.getAttributeValue(null, "mimeType").orEmpty()
                            adaptationDrm = DrmStatus.Clear
                            adaptationTemplate = null
                        }
                        "Representation" -> {
                            inRepresentation = true
                            repId = parser.getAttributeValue(null, "id").orEmpty()
                            repWidth = parser.getAttributeValue(null, "width")?.toIntOrNull() ?: 0
                            repHeight = parser.getAttributeValue(null, "height")?.toIntOrNull() ?: 0
                            repBandwidth = parser.getAttributeValue(null, "bandwidth")?.toLongOrNull() ?: 0L
                            repCodecs = parser.getAttributeValue(null, "codecs").orEmpty()
                            repMime = parser.getAttributeValue(null, "mimeType").orEmpty().ifBlank { adaptationMimeType }
                            repBaseUrl = null
                            repTemplate = null
                            timelineNumbers.clear()
                        }
                        "SegmentTemplate" -> {
                            val info = SegmentTemplateInfo(
                                initialization = parser.getAttributeValue(null, "initialization"),
                                media = parser.getAttributeValue(null, "media"),
                                startNumber = parser.getAttributeValue(null, "startNumber")?.toLongOrNull() ?: 1L,
                                timescale = parser.getAttributeValue(null, "timescale")?.toLongOrNull() ?: 1L,
                                duration = parser.getAttributeValue(null, "duration")?.toLongOrNull() ?: 0L
                            )
                            if (inRepresentation) repTemplate = info else if (inAdaptationSet) adaptationTemplate = info
                        }
                        "S" -> {
                            val t = parser.getAttributeValue(null, "t")?.toLongOrNull()
                            val d = parser.getAttributeValue(null, "d")?.toLongOrNull() ?: 0L
                            val r = parser.getAttributeValue(null, "r")?.toIntOrNull() ?: 0
                            val start = t ?: (timelineNumbers.lastOrNull()?.plus(d) ?: 0L)
                            for (repeat in 0..r) {
                                timelineNumbers += start + (repeat * d)
                            }
                        }
                    }
                }
                XmlPullParser.END_TAG -> {
                    when (parser.name) {
                        "Representation" -> {
                            val effectiveMime = repMime.ifBlank { adaptationMimeType }
                            val isAudio = adaptationContentType.equals("audio", true) ||
                                effectiveMime.startsWith("audio/", true)
                            val tpl = repTemplate ?: adaptationTemplate
                            val initUrl = tpl?.initialization?.let {
                                HlsPlaylistParser.resolveUrl(
                                    mpdBaseUrl,
                                    it.replace("\$RepresentationID\$", repId)
                                )
                            }
                            val segmentUrls = buildSegmentUrls(
                                base = repBaseUrl ?: mpdBaseUrl,
                                repId = repId,
                                bandwidth = repBandwidth,
                                tpl = tpl,
                                timeline = timelineNumbers,
                                durationSec = durationSec
                            )
                            val trackDrm = if (adaptationDrm is DrmStatus.Protected) adaptationDrm else globalDrm
                            val track = DashMediaTrack(
                                id = repId.ifBlank { "${repHeight}_$repBandwidth" },
                                mimeType = effectiveMime,
                                codecs = repCodecs,
                                width = repWidth,
                                height = repHeight,
                                bandwidthBps = repBandwidth,
                                initUrl = initUrl,
                                segmentUrls = segmentUrls,
                                durationSec = durationSec,
                                isAudio = isAudio,
                                drmStatus = trackDrm
                            )
                            if (isAudio) audioTracks += track else videoTracks += track
                            inRepresentation = false
                        }
                        "AdaptationSet" -> {
                            inAdaptationSet = false
                        }
                    }
                }
            }
            eventType = parser.next()
        }

        return ParsedDashManifest(
            durationSec = durationSec,
            videoTracks = videoTracks,
            audioTracks = audioTracks,
            drmStatus = globalDrm
        )
    }

    private fun buildSegmentUrls(
        base: String,
        repId: String,
        bandwidth: Long,
        tpl: SegmentTemplateInfo?,
        timeline: List<Long>,
        durationSec: Double
    ): List<String> {
        if (tpl?.media == null) {
            return listOf(base)
        }
        val urls = mutableListOf<String>()
        if (timeline.isNotEmpty() && tpl.media.contains("\$Time\$")) {
            for (t in timeline) {
                val resolved = tpl.media
                    .replace("\$RepresentationID\$", repId)
                    .replace("\$Bandwidth\$", bandwidth.toString())
                    .replace("\$Time\$", t.toString())
                urls += HlsPlaylistParser.resolveUrl(base, resolved)
            }
        } else {
            val segDurSec = if (tpl.duration > 0 && tpl.timescale > 0) {
                tpl.duration.toDouble() / tpl.timescale.toDouble()
            } else 4.0
            val count = if (durationSec > 0 && segDurSec > 0) {
                ceil(durationSec / segDurSec).toInt().coerceAtLeast(1)
            } else 1
            for (idx in 0 until count) {
                val number = tpl.startNumber + idx
                val resolved = tpl.media
                    .replace("\$RepresentationID\$", repId)
                    .replace("\$Bandwidth\$", bandwidth.toString())
                    .replace("\$Number\$", number.toString())
                urls += HlsPlaylistParser.resolveUrl(base, resolved)
            }
        }
        return urls
    }

    fun parseIsoDurationSeconds(iso: String?): Double {
        if (iso.isNullOrBlank()) return 0.0
        val regex = Regex("""PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+(?:\.\d+)?)S)?""")
        val match = regex.find(iso) ?: return 0.0
        val h = match.groupValues[1].toDoubleOrNull() ?: 0.0
        val m = match.groupValues[2].toDoubleOrNull() ?: 0.0
        val s = match.groupValues[3].toDoubleOrNull() ?: 0.0
        return h * 3600.0 + m * 60.0 + s
    }

    private data class SegmentTemplateInfo(
        val initialization: String?,
        val media: String?,
        val startNumber: Long,
        val timescale: Long,
        val duration: Long
    )
}
