package com.velograb.ui.viewmodel

import android.app.Application
import android.content.Intent
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.velograb.VeloGrabApp
import com.velograb.domain.model.DownloadTask
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class LibraryViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as VeloGrabApp
    private val repository = app.container.repository

    val completedVideos: StateFlow<List<DownloadTask>> = repository.observeCompletedLibrary()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000),
            initialValue = emptyList()
        )

    fun deleteVideo(task: DownloadTask) {
        viewModelScope.launch(Dispatchers.IO) {
            task.outputUri?.let { uriStr ->
                runCatching {
                    val uri = Uri.parse(uriStr)
                    if (uri.scheme == "content") {
                        app.contentResolver.delete(uri, null, null)
                    } else if (uri.scheme == "file" && uri.path != null) {
                        java.io.File(uri.path!!).delete()
                    }
                }
            }
            repository.deleteTask(task.id)
        }
    }

    fun createShareIntent(task: DownloadTask): Intent? {
        val uriStr = task.outputUri ?: return null
        val uri = Uri.parse(uriStr)
        return Intent(Intent.ACTION_SEND).apply {
            type = if (task.fileName.endsWith(".m4a")) "audio/*" else "video/*"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
    }
}
