package com.velograb.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface DownloadDao {

    @Query("SELECT * FROM downloads ORDER BY createdAtMillis DESC")
    fun observeAll(): Flow<List<DownloadEntity>>

    @Query("SELECT * FROM downloads WHERE status = 'COMPLETED' ORDER BY updatedAtMillis DESC")
    fun observeCompleted(): Flow<List<DownloadEntity>>

    @Query("SELECT * FROM downloads WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): DownloadEntity?

    @Query("SELECT * FROM downloads WHERE status IN ('QUEUED', 'PROBING', 'DOWNLOADING', 'MUXING')")
    suspend fun getActiveTasks(): List<DownloadEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: DownloadEntity)

    @Query(
        """
        UPDATE downloads SET 
            status = :status,
            progressPercent = :progressPercent,
            downloadedBytes = :downloadedBytes,
            totalBytes = :totalBytes,
            speedBytesPerSec = :speedBytesPerSec,
            etaSeconds = :etaSeconds,
            completedSegments = :completedSegments,
            totalSegments = :totalSegments,
            errorMessage = :errorMessage,
            updatedAtMillis = :updatedAtMillis
        WHERE id = :id
        """
    )
    suspend fun updateProgress(
        id: String,
        status: String,
        progressPercent: Float,
        downloadedBytes: Long,
        totalBytes: Long,
        speedBytesPerSec: Long,
        etaSeconds: Long,
        completedSegments: Int,
        totalSegments: Int,
        errorMessage: String?,
        updatedAtMillis: Long
    )

    @Query(
        """
        UPDATE downloads SET
            status = :status,
            progressPercent = 100.0,
            speedBytesPerSec = 0,
            etaSeconds = 0,
            outputUri = :outputUri,
            downloadedBytes = :finalBytes,
            totalBytes = :finalBytes,
            durationMs = :durationMs,
            errorMessage = NULL,
            updatedAtMillis = :updatedAtMillis
        WHERE id = :id
        """
    )
    suspend fun markCompleted(
        id: String,
        status: String,
        outputUri: String,
        finalBytes: Long,
        durationMs: Long,
        updatedAtMillis: Long
    )

    @Query("UPDATE downloads SET status = :status, speedBytesPerSec = 0, etaSeconds = 0, errorMessage = :errorMessage, updatedAtMillis = :updatedAtMillis WHERE id = :id")
    suspend fun updateStatus(
        id: String,
        status: String,
        errorMessage: String?,
        updatedAtMillis: Long
    )

    @Query("DELETE FROM downloads WHERE id = :id")
    suspend fun deleteById(id: String)

    // Chunk range persistence
    @Query("SELECT * FROM chunk_states WHERE downloadId = :downloadId ORDER BY chunkIndex ASC")
    suspend fun getChunks(downloadId: String): List<ChunkStateEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertChunks(chunks: List<ChunkStateEntity>)

    @Query("UPDATE chunk_states SET downloadedBytes = :downloadedBytes, isCompleted = :isCompleted WHERE downloadId = :downloadId AND chunkIndex = :chunkIndex")
    suspend fun updateChunkProgress(
        downloadId: String,
        chunkIndex: Int,
        downloadedBytes: Long,
        isCompleted: Boolean
    )

    // Segment persistence
    @Query("SELECT * FROM segment_states WHERE downloadId = :downloadId AND trackKind = :trackKind")
    suspend fun getCompletedSegments(downloadId: String, trackKind: String): List<SegmentStateEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertSegment(segment: SegmentStateEntity)
}
