package com.velograb.download

import com.velograb.data.local.ChunkStateEntity
import com.velograb.data.repository.DownloadRepository
import com.velograb.domain.model.DownloadStatus
import com.velograb.domain.model.DownloadTask
import com.velograb.network.OkHttpClientProvider
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import java.io.File
import java.io.IOException
import java.io.RandomAccessFile
import java.net.SocketTimeoutException
import java.nio.ByteBuffer
import java.util.concurrent.atomic.AtomicLong
import kotlin.math.min

class MultiThreadRangeDownloader(
    private val okHttpClient: OkHttpClient,
    private val repository: DownloadRepository
) {
    data class ProbeResult(
        val contentLength: Long,
        val supportsRanges: Boolean
    )

    suspend fun download(
        task: DownloadTask,
        tempFile: File,
        isPausedOrCancelled: () -> Boolean,
        onSpeedSample: (downloadedBytes: Long, totalBytes: Long, speedBps: Long, etaSec: Long) -> Unit
    ): File = withContext(Dispatchers.IO) {
        tempFile.parentFile?.mkdirs()

        repository.updateStatus(task.id, DownloadStatus.PROBING)
        val probe = probeServer(task)

        val totalBytes = probe.contentLength
        val useMultiThread = probe.supportsRanges && totalBytes > MIN_MULTITHREAD_BYTES

        if (useMultiThread) {
            downloadParallelChunks(task, tempFile, totalBytes, isPausedOrCancelled, onSpeedSample)
        } else {
            downloadSingleStream(task, tempFile, totalBytes, probe.supportsRanges, isPausedOrCancelled, onSpeedSample)
        }
        tempFile
    }

    private fun probeServer(task: DownloadTask): ProbeResult {
        val headReq = OkHttpClientProvider.buildRequest(task.videoUrl, task.headers)
            .newBuilder()
            .head()
            .build()

        runCatching {
            okHttpClient.newCall(headReq).execute().use { resp ->
                if (resp.isSuccessful) {
                    val len = resp.header("Content-Length")?.toLongOrNull() ?: -1L
                    val acceptRanges = resp.header("Accept-Ranges")?.equals("bytes", ignoreCase = true) == true
                    if (len > 0) {
                        return ProbeResult(len, acceptRanges)
                    }
                }
            }
        }

        // Fallback Range: bytes=0-0 probe when HEAD is unsupported (405/403)
        val rangeReq = OkHttpClientProvider.buildRequest(task.videoUrl, task.headers, extraRange = "bytes=0-0")
        okHttpClient.newCall(rangeReq).execute().use { resp ->
            val contentRange = resp.header("Content-Range")
            val totalFromRange = contentRange?.substringAfter('/')?.toLongOrNull()
            if (resp.code == 206 && totalFromRange != null && totalFromRange > 0) {
                return ProbeResult(totalFromRange, true)
            }
            val len = resp.header("Content-Length")?.toLongOrNull() ?: -1L
            return ProbeResult(len, false)
        }
    }

    private suspend fun downloadParallelChunks(
        task: DownloadTask,
        tempFile: File,
        totalBytes: Long,
        isPausedOrCancelled: () -> Boolean,
        onSpeedSample: (Long, Long, Long, Long) -> Unit
    ) = coroutineScope {
        val existingChunks = repository.getChunks(task.id)
        val chunks = if (existingChunks.size == THREAD_COUNT && tempFile.exists() && tempFile.length() == totalBytes) {
            existingChunks
        } else {
            RandomAccessFile(tempFile, "rw").use { raf ->
                raf.setLength(totalBytes)
            }
            val chunkSize = totalBytes / THREAD_COUNT
            (0 until THREAD_COUNT).map { idx ->
                val start = idx * chunkSize
                val end = if (idx == THREAD_COUNT - 1) totalBytes - 1 else ((idx + 1) * chunkSize) - 1
                ChunkStateEntity(
                    downloadId = task.id,
                    chunkIndex = idx,
                    startByte = start,
                    endByte = end,
                    downloadedBytes = 0L,
                    isCompleted = false
                )
            }.also { repository.saveChunks(it) }
        }

        val initialDownloaded = chunks.sumOf { it.downloadedBytes }
        val totalDownloaded = AtomicLong(initialDownloaded)
        val lastWindowBytes = AtomicLong(initialDownloaded)
        var lastTickMillis = System.currentTimeMillis()
        val progressLock = Any()

        val workers = chunks.filter { !it.isCompleted }.map { chunk ->
            async(Dispatchers.IO) {
                var currentOffset = chunk.startByte + chunk.downloadedBytes
                var localDownloaded = chunk.downloadedBytes
                val chunkTotal = (chunk.endByte - chunk.startByte) + 1
                var attempt = 0

                while (currentOffset <= chunk.endByte) {
                    if (isPausedOrCancelled() || !isActive) throw CancellationException("Paused")
                    try {
                        val req = OkHttpClientProvider.buildRequest(
                            url = task.videoUrl,
                            headers = task.headers,
                            extraRange = "bytes=$currentOffset-${chunk.endByte}"
                        )
                        okHttpClient.newCall(req).execute().use { resp ->
                            if (!resp.isSuccessful && resp.code != 206) {
                                if (isRetryableHttp(resp.code)) {
                                    throw IOException("HTTP ${resp.code}")
                                } else {
                                    throw IllegalStateException("Sunucu hatası: HTTP ${resp.code}")
                                }
                            }
                            val body = resp.body ?: throw IOException("Boş yanıt gövdesi")
                            val stream = body.byteStream()
                            val buffer = ByteArray(DEFAULT_BUFFER_SIZE)

                            RandomAccessFile(tempFile, "rw").channel.use { channel ->
                                channel.position(currentOffset)
                                while (true) {
                                    if (isPausedOrCancelled() || !isActive) {
                                        repository.updateChunkProgress(
                                            task.id,
                                            chunk.chunkIndex,
                                            localDownloaded,
                                            false
                                        )
                                        throw CancellationException("Paused")
                                    }
                                    val read = stream.read(buffer)
                                    if (read == -1) break

                                    val remaining = (chunk.endByte - currentOffset + 1).toInt().coerceAtLeast(0)
                                    val toWrite = min(read, remaining)
                                    if (toWrite <= 0) break

                                    val bb = ByteBuffer.wrap(buffer, 0, toWrite)
                                    while (bb.hasRemaining()) {
                                        channel.write(bb)
                                    }

                                    currentOffset += toWrite
                                    localDownloaded += toWrite
                                    val aggBytes = totalDownloaded.addAndGet(toWrite.toLong())

                                    val now = System.currentTimeMillis()
                                    synchronized(progressLock) {
                                        val elapsed = now - lastTickMillis
                                        if (elapsed >= 450L) {
                                            val delta = aggBytes - lastWindowBytes.getAndSet(aggBytes)
                                            val speedBps = (delta * 1000L) / elapsed.coerceAtLeast(1L)
                                            val eta = if (speedBps > 0) (totalBytes - aggBytes) / speedBps else 0L
                                            lastTickMillis = now
                                            onSpeedSample(aggBytes, totalBytes, speedBps, eta)
                                        }
                                    }
                                    if (localDownloaded % (256 * 1024) < DEFAULT_BUFFER_SIZE) {
                                        repository.updateChunkProgress(task.id, chunk.chunkIndex, localDownloaded, false)
                                    }
                                }
                            }
                        }

                        if (localDownloaded >= chunkTotal) {
                            repository.updateChunkProgress(task.id, chunk.chunkIndex, chunkTotal, true)
                            break
                        }
                    } catch (ce: CancellationException) {
                        throw ce
                    } catch (e: Exception) {
                        repository.updateChunkProgress(task.id, chunk.chunkIndex, localDownloaded, false)
                        if (!isRetryableException(e) || attempt >= MAX_RETRIES) {
                            throw e
                        }
                        attempt++
                        delay(computeBackoffMs(attempt))
                    }
                }
            }
        }

        workers.awaitAll()
        onSpeedSample(totalBytes, totalBytes, 0L, 0L)
    }

    private suspend fun downloadSingleStream(
        task: DownloadTask,
        tempFile: File,
        totalBytes: Long,
        supportsResume: Boolean,
        isPausedOrCancelled: () -> Boolean,
        onSpeedSample: (Long, Long, Long, Long) -> Unit
    ) {
        var existingBytes = if (supportsResume && tempFile.exists()) tempFile.length() else 0L
        if (totalBytes > 0 && existingBytes >= totalBytes) return

        var attempt = 0
        var lastWindowBytes = existingBytes
        var lastTickMillis = System.currentTimeMillis()

        while (true) {
            if (isPausedOrCancelled()) throw CancellationException("Paused")
            try {
                val rangeHeader = if (supportsResume && existingBytes > 0) "bytes=$existingBytes-" else null
                val req = OkHttpClientProvider.buildRequest(task.videoUrl, task.headers, extraRange = rangeHeader)

                okHttpClient.newCall(req).execute().use { resp ->
                    if (!resp.isSuccessful && resp.code != 206) {
                        if (isRetryableHttp(resp.code)) throw IOException("HTTP ${resp.code}")
                        throw IllegalStateException("İndirme hatası: HTTP ${resp.code}")
                    }
                    val appendMode = resp.code == 206 && existingBytes > 0
                    if (!appendMode) existingBytes = 0L

                    val expectedTotal = if (totalBytes > 0) totalBytes else (resp.body?.contentLength() ?: -1L)
                    val body = resp.body ?: throw IOException("Boş yanıt")
                    val input = body.byteStream()
                    val buffer = ByteArray(DEFAULT_BUFFER_SIZE)

                    RandomAccessFile(tempFile, "rw").use { raf ->
                        raf.seek(existingBytes)
                        if (!appendMode) raf.setLength(0L)

                        while (true) {
                            if (isPausedOrCancelled()) throw CancellationException("Paused")
                            val read = input.read(buffer)
                            if (read == -1) break
                            raf.write(buffer, 0, read)
                            existingBytes += read

                            val now = System.currentTimeMillis()
                            val elapsed = now - lastTickMillis
                            if (elapsed >= 450L) {
                                val delta = existingBytes - lastWindowBytes
                                lastWindowBytes = existingBytes
                                val speedBps = (delta * 1000L) / elapsed.coerceAtLeast(1L)
                                val eta = if (expectedTotal > 0 && speedBps > 0) {
                                    (expectedTotal - existingBytes) / speedBps
                                } else 0L
                                lastTickMillis = now
                                onSpeedSample(existingBytes, expectedTotal.coerceAtLeast(existingBytes), speedBps, eta)
                            }
                        }
                    }
                    onSpeedSample(existingBytes, existingBytes, 0L, 0L)
                    return
                }
            } catch (ce: CancellationException) {
                throw ce
            } catch (e: Exception) {
                if (!isRetryableException(e) || attempt >= MAX_RETRIES) throw e
                attempt++
                delay(computeBackoffMs(attempt))
            }
        }
    }

    companion object {
        const val THREAD_COUNT = 4
        const val MIN_MULTITHREAD_BYTES = 2L * 1024L * 1024L // 2 MB
        const val MAX_RETRIES = 15
        private const val DEFAULT_BUFFER_SIZE = 32 * 1024

        fun isRetryableHttp(code: Int): Boolean = code == 429 || code in 500..599

        fun isRetryableException(e: Throwable): Boolean =
            e is IOException || e is SocketTimeoutException

        fun computeBackoffMs(attempt: Int): Long {
            val exp = 1L shl attempt.coerceAtMost(5)
            return (500L * exp).coerceAtMost(16_000L)
        }
    }
}
