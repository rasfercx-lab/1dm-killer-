-keepclassmembers class com.velograb.sniffer.StreamJsBridge {
    @android.webkit.JavascriptInterface <methods>;
}
-keepattributes *Annotation*
-dontwarn okhttp3.**
-dontwarn okio.**
